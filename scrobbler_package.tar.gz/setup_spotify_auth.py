#!/usr/bin/env python3
"""
Spotify OAuth Setup — Interactive script to complete the initial authorization flow.
Run this once to get your refresh token.
"""

import os
import webbrowser
import http.server
import urllib.parse
import requests
from pathlib import Path
from dotenv import load_dotenv

SCRIPT_DIR = Path(__file__).parent
load_dotenv(SCRIPT_DIR / ".env")

CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
REDIRECT_URI = "http://localhost:8888/callback"
SCOPES = "user-read-recently-played"

AUTH_URL = "https://accounts.spotify.com/authorize"
TOKEN_URL = "https://accounts.spotify.com/api/token"


def get_auth_code():
    """Open browser for auth and capture the callback code."""
    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": REDIRECT_URI,
        "scope": SCOPES,
    }
    url = f"{AUTH_URL}?{urllib.parse.urlencode(params)}"
    print(f"\nOpening browser for Spotify authorization...")
    print(f"If the browser doesn't open, visit this URL manually:\n{url}\n")
    webbrowser.open(url)

    # Start a simple server to capture the callback
    auth_code = None

    class CallbackHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            nonlocal auth_code
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)
            if "code" in params:
                auth_code = params["code"][0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(
                    b"<html><body><h2>Authorization successful!</h2>"
                    b"<p>You can close this tab and return to the terminal.</p></body></html>"
                )
            else:
                error = params.get("error", ["unknown"])[0]
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(f"<html><body><h2>Error: {error}</h2></body></html>".encode())

        def log_message(self, format, *args):
            pass  # Suppress default logging

    server = http.server.HTTPServer(("localhost", 8888), CallbackHandler)
    print("Waiting for callback on http://localhost:8888/callback ...")
    server.handle_request()
    server.server_close()

    return auth_code


def exchange_code_for_tokens(code):
    """Exchange the authorization code for access and refresh tokens."""
    resp = requests.post(
        TOKEN_URL,
        data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": REDIRECT_URI,
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
    )
    resp.raise_for_status()
    return resp.json()


def save_refresh_token(refresh_token):
    """Write or update SPOTIFY_REFRESH_TOKEN in .env file."""
    env_path = SCRIPT_DIR / ".env"
    if env_path.exists():
        content = env_path.read_text()
        lines = content.splitlines()
        updated = False
        for i, line in enumerate(lines):
            if line.startswith("SPOTIFY_REFRESH_TOKEN="):
                lines[i] = f"SPOTIFY_REFRESH_TOKEN={refresh_token}"
                updated = True
                break
        if not updated:
            lines.append(f"SPOTIFY_REFRESH_TOKEN={refresh_token}")
        env_path.write_text("\n".join(lines) + "\n")
    else:
        env_path.write_text(
            f"SPOTIFY_CLIENT_ID={CLIENT_ID or 'your_client_id'}\n"
            f"SPOTIFY_CLIENT_SECRET={CLIENT_SECRET or 'your_client_secret'}\n"
            f"SPOTIFY_REFRESH_TOKEN={refresh_token}\n"
        )


def main():
    print("=" * 50)
    print("SPOTIFY OAUTH SETUP")
    print("=" * 50)

    if not CLIENT_ID or not CLIENT_SECRET:
        print("\nERROR: SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET must be set in .env")
        print("1. Go to https://developer.spotify.com/dashboard")
        print("2. Create a new app")
        print("3. Set redirect URI to: http://localhost:8888/callback")
        print("4. Copy Client ID and Client Secret to your .env file")
        return

    code = get_auth_code()
    if not code:
        print("\nERROR: Failed to get authorization code.")
        return

    print("Exchanging code for tokens...")
    tokens = exchange_code_for_tokens(code)

    refresh_token = tokens.get("refresh_token")
    if not refresh_token:
        print("\nERROR: No refresh token received.")
        return

    save_refresh_token(refresh_token)

    print("\n" + "=" * 50)
    print("SUCCESS!")
    print("=" * 50)
    print(f"Refresh token saved to .env")
    print(f"Access token expires in {tokens.get('expires_in', '?')} seconds")
    print(f"\nYou can now run: python scrobbler.py")


if __name__ == "__main__":
    main()
