#!/usr/bin/env python3
"""
Rebuild the TDUBBLETIME dashboard from updated CSV data.
Runs the data pipeline and regenerates dashboard.html with fresh data.
"""

import os
import sys
import json
import subprocess
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
WORKSPACE = SCRIPT_DIR  # Assumes scrobbler is in the same dir as CSVs


def count_csv_rows(filepath):
    """Count data rows in a CSV (excluding header)."""
    with open(filepath, "r") as f:
        return sum(1 for _ in f) - 1


def main():
    print("=" * 50)
    print("REBUILDING DASHBOARD")
    print("=" * 50)

    master_csv = WORKSPACE / "master_music.csv"
    if not master_csv.exists():
        print(f"ERROR: {master_csv} not found.")
        return

    current_rows = count_csv_rows(master_csv)
    print(f"\nCurrent master_music.csv: {current_rows:,} plays")

    # Check for previous build count
    state_file = WORKSPACE / ".last_build_count"
    if state_file.exists():
        last_count = int(state_file.read_text().strip())
        new_plays = current_rows - last_count
        print(f"Last build: {last_count:,} plays")
        print(f"New plays since last build: {new_plays:,}")
    else:
        new_plays = None
        print("First build (no previous count on record).")

    # Run data pipeline
    print("\nRunning data pipeline...")
    pipeline = WORKSPACE / "build_data_blob.py"
    if not pipeline.exists():
        print(f"ERROR: {pipeline} not found.")
        print("Place build_data_blob.py in the same directory as this script.")
        return

    result = subprocess.run(
        [sys.executable, str(pipeline)],
        capture_output=True,
        text=True,
        cwd=str(WORKSPACE),
    )
    if result.returncode != 0:
        print(f"ERROR running data pipeline:\n{result.stderr}")
        return
    print(result.stdout[-500:] if len(result.stdout) > 500 else result.stdout)

    # Regenerate HTML
    print("\nRegenerating dashboard HTML...")
    data_json = WORKSPACE / "dashboard_data.json"
    dashboard_html = WORKSPACE / "dashboard" / "index.html"

    if not data_json.exists():
        print(f"ERROR: {data_json} not found after pipeline run.")
        return

    # Read existing HTML template (everything except the DATA blob)
    if dashboard_html.exists():
        html_content = dashboard_html.read_text(encoding="utf-8")
        # Find and replace the DATA blob
        start_marker = "const DATA = "
        end_marker = ";\n// END DATA"
        
        start_idx = html_content.find(start_marker)
        end_idx = html_content.find(end_marker)
        
        if start_idx != -1 and end_idx != -1:
            new_data = data_json.read_text(encoding="utf-8")
            new_html = (
                html_content[:start_idx]
                + f"const DATA = {new_data};\n// END DATA"
                + html_content[end_idx + len(end_marker):]
            )
            dashboard_html.write_text(new_html, encoding="utf-8")
            print(f"Dashboard updated: {dashboard_html}")
        else:
            print("WARNING: Could not find DATA markers in dashboard HTML.")
            print("You may need to manually regenerate the full dashboard.")
    else:
        print(f"WARNING: {dashboard_html} not found. Generate it first.")

    # Save build count
    state_file.write_text(str(current_rows))

    print(f"\nDashboard rebuilt with {current_rows:,} total plays.", end="")
    if new_plays is not None:
        print(f" New plays since last build: {new_plays:,}")
    else:
        print()
    print("Done!")


if __name__ == "__main__":
    main()
