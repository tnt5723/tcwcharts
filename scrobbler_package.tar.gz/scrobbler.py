#!/usr/bin/env python3
"""
TDUBBLETIME Auto-Scrobbler
Polls Spotify's recently-played endpoint and appends new tracks to master_music.csv.
Designed to run once daily via cron.
"""

import os
import csv
import json
import requests
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
from dotenv import load_dotenv
from pathlib import Path

# ─── Config ───
SCRIPT_DIR = Path(__file__).parent
load_dotenv(SCRIPT_DIR / ".env")

CLIENT_ID = os.getenv("SPOTIFY_CLIENT_ID")
CLIENT_SECRET = os.getenv("SPOTIFY_CLIENT_SECRET")
REFRESH_TOKEN = os.getenv("SPOTIFY_REFRESH_TOKEN")

MASTER_CSV = SCRIPT_DIR / "master_music.csv"
ET = ZoneInfo("America/New_York")
DEDUP_WINDOW_SECONDS = 120


def refresh_access_token():
    """Exchange refresh token for a new access token."""
    resp = requests.post(
        "https://accounts.spotify.com/api/token",
        data={
            "grant_type": "refresh_token",
            "refresh_token": REFRESH_TOKEN,
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        },
    )
    resp.raise_for_status()
    data = resp.json()
    # Update refresh token if rotated
    if "refresh_token" in data:
        update_env_refresh_token(data["refresh_token"])
    return data["access_token"]


def update_env_refresh_token(new_token):
    """Update the .env file with a new refresh token."""
    env_path = SCRIPT_DIR / ".env"
    lines = env_path.read_text().splitlines()
    new_lines = []
    for line in lines:
        if line.startswith("SPOTIFY_REFRESH_TOKEN="):
            new_lines.append(f"SPOTIFY_REFRESH_TOKEN={new_token}")
        else:
            new_lines.append(line)
    env_path.write_text("\n".join(new_lines) + "\n")


def get_recently_played(access_token):
    """Fetch up to 50 recently played tracks from Spotify."""
    resp = requests.get(
        "https://api.spotify.com/v1/me/player/recently-played",
        headers={"Authorization": f"Bearer {access_token}"},
        params={"limit": 50},
    )
    resp.raise_for_status()
    return resp.json().get("items", [])


def load_existing_records():
    """Load existing records from master_music.csv for dedup check."""
    records = []
    if not MASTER_CSV.exists():
        return records
    with open(MASTER_CSV, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            records.append({
                "timestamp_et": row["timestamp_et"],
                "artist": row["artist"].lower(),
                "track": row["track"].lower(),
            })
    return records


def is_duplicate(new_ts_et, new_artist, new_track, existing_records):
    """Check if a record already exists within the dedup window."""
    new_dt = datetime.strptime(new_ts_et, "%Y-%m-%d %H:%M:%S")
    new_a = new_artist.lower()
    new_t = new_track.lower()
    window = timedelta(seconds=DEDUP_WINDOW_SECONDS)

    # Check last 200 records (optimization — recently played won't match old records)
    for rec in existing_records[-200:]:
        if rec["artist"] == new_a and rec["track"] == new_t:
            existing_dt = datetime.strptime(rec["timestamp_et"], "%Y-%m-%d %H:%M:%S")
            if abs(new_dt - existing_dt) <= window:
                return True
    return False


def utc_to_eastern_str(utc_str):
    """Convert Spotify UTC timestamp to Eastern naive datetime string."""
    # Spotify format: "2024-01-15T14:30:00.000Z"
    dt_utc = datetime.fromisoformat(utc_str.replace("Z", "+00:00"))
    dt_et = dt_utc.astimezone(ET).replace(tzinfo=None)
    return dt_et.strftime("%Y-%m-%d %H:%M:%S"), dt_et


def derived_columns(dt_et):
    """Compute year, month, day_of_week, hour, is_weekend."""
    dow = dt_et.strftime("%A")
    return {
        "year": dt_et.year,
        "month": dt_et.month,
        "day_of_week": dow,
        "hour": dt_et.hour,
        "is_weekend": dow in ("Saturday", "Sunday"),
    }


def main():
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{now}] Starting scrobbler...")

    if not all([CLIENT_ID, CLIENT_SECRET, REFRESH_TOKEN]):
        print("ERROR: Missing Spotify credentials. Run setup_spotify_auth.py first.")
        return

    # Get access token
    access_token = refresh_access_token()
    print("  Access token refreshed.")

    # Fetch recently played
    items = get_recently_played(access_token)
    print(f"  Fetched {len(items)} recently played tracks from Spotify.")

    if not items:
        print("  No tracks found. Done.")
        return

    # Load existing for dedup
    existing = load_existing_records()
    print(f"  Loaded {len(existing):,} existing records for dedup check.")

    # Process new tracks
    new_rows = []
    for item in items:
        track = item.get("track", {})
        played_at = item.get("played_at", "")
        if not played_at:
            continue

        artist_name = track.get("artists", [{}])[0].get("name", "")
        track_name = track.get("name", "")
        album_name = track.get("album", {}).get("name", "")
        duration_ms = track.get("duration_ms", 0)

        if not artist_name or not track_name:
            continue

        ts_et_str, dt_et = utc_to_eastern_str(played_at)

        if is_duplicate(ts_et_str, artist_name, track_name, existing):
            continue

        cols = derived_columns(dt_et)
        new_rows.append({
            "timestamp_et": ts_et_str,
            "artist": artist_name,
            "track": track_name,
            "album": album_name,
            "ms_played": duration_ms,
            "source": "Spotify_Live",
            "year": cols["year"],
            "month": cols["month"],
            "day_of_week": cols["day_of_week"],
            "hour": cols["hour"],
            "is_weekend": cols["is_weekend"],
            "is_one_hit_wonder": False,
        })

        # Add to existing for subsequent dedup checks within this batch
        existing.append({
            "timestamp_et": ts_et_str,
            "artist": artist_name.lower(),
            "track": track_name.lower(),
        })

    # Append to CSV
    if new_rows:
        fieldnames = [
            "timestamp_et", "artist", "track", "album", "ms_played", "source",
            "year", "month", "day_of_week", "hour", "is_weekend", "is_one_hit_wonder",
        ]
        file_exists = MASTER_CSV.exists()
        with open(MASTER_CSV, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            writer.writerows(new_rows)

    print(f"  Checked {len(items)} tracks. Added {len(new_rows)} new records.")
    print(f"  Done.")


if __name__ == "__main__":
    main()
