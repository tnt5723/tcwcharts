# Auto-Scrobbler Setup Guide

## Prerequisites
- Python 3.8+
- `pip install requests python-dotenv`

## Step 1: Create a Spotify Developer App
1. Go to https://developer.spotify.com/dashboard
2. Create a new app
3. Set redirect URI to: `http://localhost:8888/callback`
4. Note your Client ID and Client Secret

## Step 2: Configure Credentials
1. Copy `.env.example` to `.env`
2. Fill in `SPOTIFY_CLIENT_ID` and `SPOTIFY_CLIENT_SECRET`

```bash
cp .env.example .env
# Edit .env with your credentials
```

## Step 3: Authorize
```bash
python setup_spotify_auth.py
```
Follow the browser prompts. The refresh token will be saved to `.env` automatically.

## Step 4: Test
```bash
python scrobbler.py
```
Verify it prints the count of new tracks found.

## Step 5: Schedule Daily Runs

### macOS/Linux (cron):
```bash
crontab -e
```
Add this line (adjust the path):
```
0 6 * * * cd /path/to/scrobbler && python3 scrobbler.py >> scrobbler.log 2>&1
```

### Windows (Task Scheduler):
Create a basic task that runs daily at 6am:
- Program: `python`
- Arguments: `C:\path\to\scrobbler\scrobbler.py`
- Start in: `C:\path\to\scrobbler`

### Cloud (GitHub Actions — free):
Create `.github/workflows/scrobble.yml`:
```yaml
name: Daily Scrobble
on:
  schedule:
    - cron: '0 11 * * *'  # 6am ET (UTC-5)
  workflow_dispatch:       # Manual trigger

jobs:
  scrobble:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install requests python-dotenv
      - run: python scrobbler.py
        env:
          SPOTIFY_CLIENT_ID: ${{ secrets.SPOTIFY_CLIENT_ID }}
          SPOTIFY_CLIENT_SECRET: ${{ secrets.SPOTIFY_CLIENT_SECRET }}
          SPOTIFY_REFRESH_TOKEN: ${{ secrets.SPOTIFY_REFRESH_TOKEN }}
      - uses: stefanzweifel/git-auto-commit-action@v5
        with:
          commit_message: "Auto-scrobble update"
```

## Step 6: Rebuild Dashboard
After new data accumulates:
```bash
python rebuild_dashboard.py
```
Open `dashboard/index.html` in your browser.

## How It Works
- `scrobbler.py` calls Spotify's `/me/player/recently-played` endpoint (up to 50 tracks)
- Each track is checked against existing records: same artist + track within 120 seconds = duplicate
- New plays are appended to `master_music.csv` with source = "Spotify_Live"
- `rebuild_dashboard.py` re-runs the data pipeline and updates the dashboard HTML

## Notes
- Spotify's recently-played endpoint only returns the last 50 tracks
- Running once daily is usually sufficient; twice daily if you listen heavily
- The refresh token auto-rotates — the script updates `.env` when Spotify issues a new one
